'use client'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { SessionProvider } from 'next-auth/react'
import { useState } from 'react'
import { Toaster as SonnerToaster } from 'sonner'
import { Toaster } from '@/components/ui/toaster'

export function Providers({ children }: { children: React.ReactNode }) {
  const [qc] = useState(() => new QueryClient({
    defaultOptions: {
      queries: {
        refetchOnWindowFocus: false,
        retry: 1,
        staleTime: 30_000,
      },
    },
  }))
  return (
    <SessionProvider>
      <QueryClientProvider client={qc}>
        {children}
        <SonnerToaster richColors position="top-right" />
        <Toaster />
      </QueryClientProvider>
    </SessionProvider>
  )
}
